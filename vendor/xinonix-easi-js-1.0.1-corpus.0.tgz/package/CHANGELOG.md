# Changelog

## Unreleased — corpus hardening

- Read undefined-length UN sequences as nested implicit-VR little-endian datasets,
  retaining the declared UN VR and restoring each enclosing encoding scope.
- Preserve those scopes in native writing, including explicit big-endian outer
  datasets. Generated streaming boundary and lifecycle tests cover both paths.
- Reject dataset-level Deflated Explicit VR Little Endian with an explicit
  unsupported-operation diagnostic after File Meta; compressed bytes are not
  interpreted as ordinary dataset headers.


## 1.0.0 - 2026-10-09

First stable EASI JS release, incorporating the release candidate's streaming DICOM, selection, custom mapping, writing, FHIR R4 ImagingStudy, and bounded Node.js DIMSE APIs. Published as `@xinonix/easi-js` under npm's `latest` tag, with native ES modules, Node.js 22/24 support, and browser-compatible core workflows.

- Include the comprehensive installation and usage guide, Community License, and complete third-party notices in the runtime-only package, with no required npm runtime dependencies.
- Link npm package metadata and documentation to the clean public source repository. Make the EASI JS license visible at the repository root as well as in the package.
- Keep original DICOM, derived image/metadata samples, and external native tools in the ignored local developer kit; replace public test dependencies with independently generated synthetic DICOM.
- Preserve native endian, signed/unsigned pixel, multiframe, nested sequence, malformed fragment, RLE, JPEG, lossless JPEG, and genuine JPEG 2000 regression coverage. Large streaming checks now use mandatory generated inputs.
- Generate default benchmark inputs and provide an offline synthetic sample in the Kitchen Sink and a fresh-checkout ImageBridge demo.
- Add an offline synthetic corpus harness with exact output checks across all six pipeline scenarios; keep private corpus runs optional.
- Add a source publication check for accidentally tracked imaging assets.
- Bundle the required API and codec/plugin contract snapshot so source tests and CI run without the private documentation repo; keep explicit overrides strict and refresh the snapshot during maintainer generation.
- Fix native dump execution, promise error reporting, and argument handling; allow a local tool override or a tool installed on PATH.
- Correct signed RLE sample rendering, including stored-bit masking and 8-bit signed input.
- Honor the pipeline's codec registry when rendering RGBA assets, including isolated JPEG 2000 providers.
- Preserve source byte order while reading numeric metadata during native big-endian to little-endian transcoding; verify exact 16-bit pixel output through fragmented and streamed inputs.
- Read Part-10 transfer syntax information in the corpus harness's transcode scenario and use a valid default AE title in ImageBridge.
- Pin the optional dcm4che comparison benchmark's source release to its Maven dependency and preserve mismatched or modified local checkouts.

The Community License permits eligible community use, including organization groups strictly below USD 5 million in annual consolidated gross revenue and qualifying research/nonprofit exceptions. Other use requires commercial licensing. The license is source-available, and optional codec providers keep their own terms. Examples, the Kitchen Sink, fixtures, and development tools remain in the source checkout rather than the npm archive.

## 1.0.0-rc.1

First installable EASI JS release candidate under the `@xinonix/easi-js` package name.

- Native ESM public entry points for the EASI factory, DICOM models, FHIR R4 imaging models, mapping/selection extensions, codecs, and Node DIMSE transports.
- Streaming native DICOM and DICOM JSON/XML metadata parsing, selection, and writing.
- FHIR R4 ImagingStudy mapping with contained/referenced subjects, hierarchy aggregation, and validated resource serialization.
- Node DIMSE Verification/Store and Study Root FIND/GET/MOVE support within the documented operation profile.
- Node 22/24 package validation, clean installed-consumer workflows, and browser bundling/smoke checks.
- Explicit runtime-only package contents with no required npm runtime dependencies.
- EASI JS Community License with a USD 5 million consolidated revenue threshold and preserved third-party licenses/notices.

This release candidate supports installation and review. Registry candidates use the `next` distribution tag; stable promotion is a separate release step. Examples and the Kitchen Sink are maintained in the source checkout rather than shipped in the library archive. Public repository/history clearance and final commercial order terms are handled separately from distribution of this reviewed runtime package.
